# Publishing Budget Passbook — Step by Step

This is your complete checklist. Do the three parts **in order**:
**Part 1 (GitHub) → Part 2 (Cloudflare) → Part 3 (Google Play)**.

Don't rush — each part only takes 15-30 minutes. Take breaks between parts if you want.

---

## PART 1: Put your app on the internet (GitHub)

Think of this like putting your app in a public locker that anyone can visit with a web address.

### Step 1 — Make a GitHub account
1. Go to **github.com**
2. Click **Sign up**
3. Pick a username, enter your email, make a password
4. Confirm your email when they send you a link

*(Skip this if you already have a GitHub account — you've used GitHub Pages before for your AHT calculator, so you probably already have one!)*

### Step 2 — Create a new repository (a folder for your app)
1. Click the **+** icon top-right → **New repository**
2. Name it: `budget-passbook`
3. Make sure it's set to **Public**
4. Click **Create repository**

### Step 3 — Upload your app files
1. On your new repository page, click **uploading an existing file** (or the **Add file → Upload files** button)
2. Drag in these files from the `budget-passbook-worker-version` folder I gave you:
   - `index.html`
   - `manifest.json`
   - `sw.js`
   - `privacy-policy.html`
   - the whole `icons` folder
3. Scroll down, click **Commit changes**

*(Don't upload the `worker` folder here — that goes to Cloudflare in Part 2, not GitHub.)*

### Step 4 — Turn on GitHub Pages (this makes it a real website)
1. Click **Settings** (top menu of your repository)
2. Click **Pages** (left sidebar)
3. Under "Branch," pick **main** and folder **/ (root)**
4. Click **Save**
5. Wait 1-2 minutes, then refresh the page

### Step 5 — Get your app's web address
At the top of that same Pages settings screen, you'll see something like:
```
https://yourusername.github.io/budget-passbook/
```
**Copy this URL and save it somewhere** — you'll need it in both Part 2 and Part 3.

✅ **Check yourself:** open that URL on your phone. You should see your Budget Passbook app!

---

## PART 2: Turn on AI for everyone (Cloudflare)

Right now the AI buttons in your app won't work yet — they need a helper server. This part builds that helper. It's the most technical part, but just follow each step exactly.

### Step 1 — Make a free Cloudflare account
1. Go to **dash.cloudflare.com/sign-up**
2. Enter your email, make a password
3. Confirm your email

### Step 2 — Get an Anthropic API key (this is what powers the AI)
1. Go to **console.anthropic.com**
2. Sign up / log in
3. Click **Settings → API Keys**
4. Click **Create Key**, give it any name like "budget-passbook"
5. **Copy the key immediately and save it somewhere safe** — you can't see it again after this
6. Add a small amount of credit to your account (even ₹500 will last a long time for personal use)

### Step 3 — Install the tools on your computer
Open a terminal (Command Prompt on Windows, Terminal on Mac) and type:
```bash
npm install -g wrangler
```
*(If this gives an error, you need Node.js first — download it from **nodejs.org**, install it, then try the command again.)*

### Step 4 — Log in to Cloudflare from your terminal
```bash
wrangler login
```
This opens your browser — click **Allow**.

### Step 5 — Set up the storage Cloudflare needs
1. In your terminal, go into the `worker` folder I gave you:
   ```bash
   cd path/to/budget-passbook-worker-version/worker
   ```
2. Run:
   ```bash
   wrangler kv namespace create RATE_LIMIT_KV
   ```
3. It prints something with an `id = "...."` — **copy that id**
4. Open `wrangler.toml` in a text editor, find this line:
   ```
   id = "REPLACE_WITH_YOUR_KV_NAMESPACE_ID"
   ```
   and paste your real id in place of that text. Save the file.

### Step 6 — Give the helper server your API key (secretly)
```bash
wrangler secret put ANTHROPIC_API_KEY
```
Paste the key you saved in Step 2 when it asks, then press Enter.

### Step 7 — Launch it!
```bash
wrangler deploy
```
It prints a web address like:
```
https://budget-passbook-ai.yourname.workers.dev
```
**Copy this address too.**

### Step 8 — Connect your app to this helper server
1. Open `index.html` (the one you uploaded to GitHub) in a text editor
2. Find this line near the top:
   ```js
   const WORKER_URL = "https://budget-passbook-ai.YOUR-SUBDOMAIN.workers.dev";
   ```
3. Replace it with **your real address** from Step 7
4. Save the file
5. Go back to GitHub, upload this updated `index.html` again (same steps as Part 1, Step 3) — this replaces the old one

✅ **Check yourself:** open your app on your phone again, add an expense, and see if the "✨ Suggested category" chip appears. If it does, AI is working!

---

## PART 3: Get it into the Google Play Store

### Step 1 — Package your app using PWABuilder
1. Go to **pwabuilder.com**
2. Paste your GitHub Pages address from Part 1, Step 5
3. Click **Start**
4. It scores your app — you should see mostly green checkmarks
5. Click **Package for stores → Android**
6. Download the **.aab file** and the **signing key file** it gives you — save both somewhere safe, you'll need the signing key forever for future updates

### Step 2 — Add the ownership proof file
1. PWABuilder also gives you a file called `assetlinks.json`
2. In your GitHub repository, create a new folder called `.well-known`
3. Upload `assetlinks.json` inside that folder
4. It should now be visible at:
   ```
   https://yourusername.github.io/.well-known/assetlinks.json
   ```

### Step 3 — Create your Google Play Developer account
1. Go to **play.google.com/console**
2. Sign in with a Google account
3. Pay the **one-time $25 fee**
4. Fill in your developer details

### Step 4 — Create your app listing
1. Click **Create app**
2. App name: `Budget Passbook`
3. Language: English (India)
4. Type: App, Free
5. Click **Create app**

### Step 5 — Fill in the store listing
Use the text I already wrote for you:
- **Short description**: paste the one I gave you
- **Full description**: paste the one I gave you
- **Screenshots**: upload the 3 phone-frame images I made
- **App icon**: use `icon-512.png` from your icons folder
- **Category**: Finance
- **Privacy policy URL**: 
  ```
  https://yourusername.github.io/privacy-policy.html
  ```

### Step 6 — Fill in the Data Safety form
When it asks what data you collect, answer:
- Financial info: **Yes, collected** → shared with Anthropic → only when the user chooses to use AI features → not sold
- Everything else: **No**

### Step 7 — Upload your app file
1. Go to **Testing → Internal testing** (do this first, not straight to production)
2. Click **Create release**
3. Upload the `.aab` file from Step 1
4. Save, then click **Review release**

### Step 8 — Test it yourself first
1. Add your own email as a tester
2. Install the app from the special testing link Google gives you
3. Make sure it opens, and the AI buttons work
4. If everything's good, come back to Play Console and click **Promote to Production**

### Step 9 — Submit for review
Click **Send for review**. Google usually takes anywhere from a few hours to a couple of days to approve it.

✅ **Done!** Once approved, your app is live on the Play Store.

---

## If something breaks

- **App doesn't show on GitHub Pages** → wait 5 minutes and hard-refresh (Ctrl+Shift+R)
- **AI buttons don't respond** → double check `WORKER_URL` in `index.html` matches exactly what `wrangler deploy` printed
- **Play Console rejects the app** → they'll email you exactly why — most common reason is a missing or broken privacy policy link, so double-check that URL opens correctly first
